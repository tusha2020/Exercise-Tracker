package ui;

// This [Class] references code from TellerApp
// Link: [https://github.students.cs.ubc.ca/CPSC210/TellerApp]
//
public class Main {
    public static void main(String[] args) {
        new ExerciseTrackerApplication();
    }
}
